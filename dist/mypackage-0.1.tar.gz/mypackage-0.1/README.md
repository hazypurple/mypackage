# mypackage_tut

this library was created as an sample of how to publish your own Python package

## building this package locally
'python setup.py sdist'

##installing this package from github
'pip install git+https:..github.com/hazypurple/mypackage_tut.git'

## updating this package from github
'pip install --upgrade git+https://github.com/hazypurple/mypackage_tut.git'
